function reset_password(){
    let email = document.getElementById("email").value;
    let auth = firebase.auth();

    auth.sendPasswordResetEmail(email).then(function() {
        // Email sent.
        alert("PasswordResetEmail is sent");
        window.location.href="login.html";
    }).catch(function(error) {
    // An error happened.
        const errorCode = error.code;
        const errorMessage = error.message;
        alert("Error: " + errorMessage + "\n" +"Error Code: " +errorCode);
    });
}

function enter(){
    if(window.event.keyCode==13){
        reset_password();
    }
  }
  
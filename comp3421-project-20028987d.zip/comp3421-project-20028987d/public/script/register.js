function register_check(){

  let isValid = true;

  let inputs = document.getElementsByClassName('form-control');
  let invalid_feedbacks = document.getElementsByClassName('invalid-feedback');

  console.log(inputs);
  console.log(invalid_feedbacks);

  let i;

  for (i=0; i<inputs.length;i++){
    if(inputs[i].checkValidity() == false){
      isValid = false;
      invalid_feedbacks[i].classList.add("d-block");
    }
    else{
      invalid_feedbacks[i].classList.remove("d-block");
    }
  }

  let password = document.getElementById("password");
  let confirm_password = document.getElementById("confirm_password");

  if(password.value != confirm_password.value){
      isValid = false;
      invalid_feedbacks[3].classList.add("d-block");
  }

  let email = document.getElementById("email");

  const database = firebase.database();

  console.log(isValid);

  if(isValid == true){
    firebase.auth().createUserWithEmailAndPassword(email.value, password.value).then( u=>{

      database.ref('users/'+ u.user.uid).set({
        "full_name": inputs[0].value,
        "email": email.value,
        "birth_date": inputs[4].value,
        "phone_number": inputs[5].value,
        "gender": inputs[6].value,
        "account_wallet": 0
      }).then(()=>{
        var user = firebase.auth().currentUser;
        user.sendEmailVerification().then(function() {
            // Email sent.
            alert("\nSign up Successfully.\n Email verification is sent.\n Please check your email: " + email.value);
            window.location.href="login.html";
          }).catch(function(error) {
            // An error happened.
            alert("Error: "+ error.message + "\n" + error.code);
          });
      });

    }).catch((error) => {
      // Handle Errors here.
      const errorCode = error.code;
      const errorMessage = error.message;
      alert("Error: " + errorMessage + "\n" + "Error Code: " +errorCode);
      // ...
    });
  }

}

function enter(){
  if(window.event.keyCode==13){
      register_check();
  }
}
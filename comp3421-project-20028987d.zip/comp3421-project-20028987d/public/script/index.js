
function onload_function(){
  let user_state = document.getElementById("myaccount");
  let myaccount_dropdown = document.getElementById("myaccount_dropdown");

  if(!firebase.database().ref('/users/'+localStorage.getItem("uid"))|| !localStorage.getItem("uid")){
    user_state.innerHTML='<i class="fa fa-user" aria-hidden="true"></i>&nbsp;Login';
    user_state.classList.remove("dropdown-toggle");
    user_state.classList.remove("dropdown-toggle-split"); 
    user_state.removeAttribute("data-toggle") ;
    myaccount_dropdown.classList.add("d-none");
  }
  else{
    user_state.innerHTML='<i class="fa fa-user" aria-hidden="true"></i>&nbsp;My account&nbsp;';
    user_state.classList.add("dropdown-toggle");
    user_state.classList.add("dropdown-toggle-split"); 
    user_state.setAttribute("data-toggle","dropdown");
    myaccount_dropdown.classList.remove("d-none");
    get_profile();
  }
  
}

window.onload = function(){
  onload_function();
  getBrands();
  generate_brands_card_body();
}

function myaccount(){
    if(!firebase.database().ref('/users/'+localStorage.getItem("uid"))|| !localStorage.getItem("uid")){
        window.location.href="login.html";
    }
}

function logout(){
  localStorage.removeItem("uid");
  onload_function();
  window.location.reload();
}


function get_profile(){

  let full_name = document.getElementById("full_name");
  let birth_day = document.getElementById("birth_day");
  let phone_number = document.getElementById("phone_number");
  let gender = document.getElementById("gender");
  let account_wallet_input = document.getElementById("account_wallet_input");


  firebase.database().ref('users/'+localStorage.uid).once('value').then(result=>{
    full_name.value = result.val().full_name;
    birth_day.value = result.val().birth_date;
    phone_number.value = result.val().phone_number;
    gender.value = result.val().gender;
    account_wallet_input.value = result.val().account_wallet;
  })


}

function active_payment_record(){
  active_pane("payment_record");
  getPaymentRecords();
}

function active_profile(){
  let nav_link = document.getElementsByClassName("nav-item");

  active_pane("profile");

  let i;
  for(i = 0; i < nav_link.length;i++){
    nav_link[i].classList.remove("active");
  }

}

function setting_profile(){
  get_profile();

  let setting = document.getElementById("setting");
  let reset = document.getElementById("reset");

  let full_name = document.getElementById("full_name");
  let birth_day = document.getElementById("birth_day");
  let phone_number = document.getElementById("phone_number");
  let gender = document.getElementById("gender");

  if(setting.innerHTML=="Setting"){
    setting.innerHTML = "Save";

    reset.classList.remove("d-none");

    full_name.readOnly = false;
    birth_day.readOnly = false;
    phone_number.readOnly = false;
    gender.readOnly = false;
  }
  else{
    setting.innerHTML = "Setting";

    reset.classList.add("d-none");

    full_name.readOnly = true;
    birth_day.readOnly = true;
    phone_number.readOnly = true;
    gender.readOnly = true;

    firebase.database().ref('users/'+localStorage.uid).update({
      'full_name': full_name.value,
      'birth_date':birth_day.value,
      'phone_number':phone_number.value,
      'gender':gender.value
    }).then(function(){
      alert("Save Successfully");
    }).catch(function(error){
      const errorCode = error.code;
      const errorMessage = error.message;
      alert("Error: " + errorMessage + "\n" + "Error Code: " +errorCode);
    });


  }
  

}

function reset_profile(){
  get_profile();
}

let go_to_top_button = document.getElementById("go_to_top_button");

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    go_to_top_button.style.display = "block";
  } else {
    go_to_top_button.style.display = "none";
  }
}

function go_to_top(){
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}

function writeBrand(brand_id,brand_name){
  firebase.database().ref('brands/'+brand_id).set({
    'brand_id': brand_id,
    'brand_name': brand_name
  });
}

function writeBrands(){
  let i;
  for(i=0;i<27;i++){
    writeBrand(i,"brand "+i);
  }
}

//writeBrands();


  
function active_pane(id){

  let tab_pane = document.getElementsByClassName("tab-pane");
  let i;

  for(i=0;i<tab_pane.length;i++){
    tab_pane[i].classList.remove("active");
    tab_pane[i].classList.add("fade");
  }

  document.getElementById(id).classList.add("active");
  document.getElementById(id).classList.remove("fade");
}


function isEmptyCart(){
  let shopping_cart_number = document.getElementById("shopping_cart_number");
  if(shopping_cart_number.innerText==0){
    return true;
  }
  else{
    return false;
  }
}

function active_cart(){
  active_pane("shopping_cart");
  if(isEmptyCart()){
    document.getElementById("not_empty_cart").style.display = "none";
    document.getElementById("empty_cart").style.display = "block";
  }else{
    document.getElementById("not_empty_cart").style.display = "block";
    document.getElementById("empty_cart").style.display = "none";
  }
  setPriceAndWalletHtml();
}

function active_item(){
  active_pane("item");
}

function active_items(){
  let nav_link = document.getElementsByClassName("nav-link");

  active_pane("items");

  let i;
  for(i = 0; i < nav_link.length;i++){
    if(i!=1){
      nav_link[i].classList.remove("active");
    }
    else{
      nav_link[i].classList.add("active");
    }
  }

}




function getBrands(){
  let brands = firebase.database().ref('brands');
  brands.on("value",function(snapshot){
    snapshot.forEach(snap => {
      const issue = snap.val();
      document.getElementById("brands").innerHTML += 
      `
      <div class="card" onclick="set_filter('brand_${issue.brand_id}')" onMouseOver="this.style.transform= 'scale(1.05)'" onMouseOut="this.style.transform= 'scale(1)'" style="width: 200px; height: 200px; background-color: #292b2c; color:#f7f7f7; float:left; margin:0 0 20px 50px; cursor: pointer;transition: all 0.3s;">
        <img src="images/brand.jpg" class="card-img-top">  
        <div class="card-body">
          <p class="card-text" style="text-align: center;">${issue.brand_name}</p>
        </div>
      </div>
      `;
    })
  })
 

}

function collapse_item(){

  let collapse_item = document.getElementsByClassName("multi-collapse");
  let i;
  for(i=0;i<collapse_item.length;i++){
    collapse_item[i].classList.remove("show");
  }
}

function expand_item(){


  let collapse_item = document.getElementsByClassName("multi-collapse");
  let i;
  for(i=0;i<collapse_item.length;i++){
    collapse_item[i].classList.add("show");
  }
}

function generate_brands_card_body(){
  let brands_card_body = document.getElementById("brand_card_body");

  let i;
  for(i=0;i<27;i++){
    brands_card_body.innerHTML +=
    `
      <div class="form-check">
      <input class="form-check-input" type="checkbox" value="brand_${i}" id="brand_${i}_input" onclick="set_filter('brand_${i}')">
      <label class="form-check-label" for="brand_${i}_input">brand ${i}</label>
      </div>
    `
  }

}

$( function() {
  $( "#slider-range" ).slider({
    range: true,
    min: 0,
    max: 500,
    values: [ 0, 500 ],
    slide: function( event, ui ) {
      $("#min_price")[0].innerHTML=$( "#slider-range" ).slider( "values", 0 );
      $("#max_price")[0].innerHTML=$( "#slider-range" ).slider( "values", 1 );
    }
  });

  $("#min_price")[0].innerHTML=$( "#slider-range" ).slider( "values", 0 );
  $("#max_price")[0].innerHTML=$( "#slider-range" ).slider( "values", 1 );

} );


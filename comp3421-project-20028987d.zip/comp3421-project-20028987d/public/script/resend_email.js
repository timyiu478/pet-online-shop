function resend_email(){
    let email = document.getElementById("resend_email_email").value;
    let password = document.getElementById("resend_email_password").value;
    firebase.auth().signInWithEmailAndPassword(email, password).then(() =>{
        let user = firebase.auth().currentUser;
        user.sendEmailVerification().then(function() {
            // Email sent.
            alert("Email verification is sent.\n Please check your email: " + email);
            window.location.href="login.html";
        }).catch(function(error) {
            // An error happened.
            alert(error.message);
        });
    }).catch(function(error) {
        // An error happened.
        const errorCode = error.code;
        const errorMessage = error.message;
        alert("Error: " + errorMessage + "\n" + "Error Code: " +errorCode);
    });
}

function enter(){
    if(window.event.keyCode==13){
        resend_email();
    }
  }
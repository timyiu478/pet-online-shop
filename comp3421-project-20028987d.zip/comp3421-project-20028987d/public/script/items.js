function addSearchTags(){
    let search_tags_datalist = document.getElementById("search_tags");
    let search_tags = [];
    let items_db = firebase.database().ref('items');
    items_db.on("value",function(snapshot){
        snapshot.forEach(snap => {
            const issue = snap.val();
            for(let i=0;i<issue.keyword.length;i++){
                search_tags.push(issue.keyword[i]);
            }  
        })
        let unique_search_tags = [...new Set(search_tags)];;
        for(let i=0; i<unique_search_tags.length;i++){
            let op = document.createElement("option");
            op.setAttribute("value",unique_search_tags[i]);
            search_tags_datalist.appendChild(op);
        }
    })

}
addSearchTags();

class item{
    constructor(id,price,brand_id,animal_type,item_type,sale_date, current_quantity ){
        this.id = id;
        this.name = "item_" + id;
        this.price = price;
        this.brand_id = brand_id;
        this.brand_name = "brand_" + brand_id;
        this.animal_type = animal_type;
        this.item_type = item_type;
        this.sale_date = sale_date;
        this.current_quantity = current_quantity;

        this.saled_quantity = 0;
        this.comments = [];
        this.keyword = [this.id,this.name,this.price,this.sale_date,this.current_quantity,this.saled_quantity,this.brand_id,this.brand_name,this.animal_type,this.item_type];
    }

    get_saled_quantity(){
        return this.saled_quantity;
    }

    set_saled_quantity(n){
        this.saled_quantity += n;
    }

    get_comments(){
        return this.saled_quantity;
    }

    set_comments(comment){
        this.saled_quantity.push(comment);
    }

    get_keyword(){
        return this.keyword;
    }
    
}


let prices = [10,20,30,40,50,60,70,80,90,100,150,200,250,300,250,400,450];
let brand_ids = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26];
let sale_dates = [2016,2017,2018,2019,2020,2021];
let current_quantities = [0,50,100,150,200,250];
let animal_types = ["dog","cat","small_animal"];
let dog_types = ["dog_food","dog_milk", "dog_treats", "dog_training","dog_toy"];
let cat_types = ["cat_food","cat_milk", "cat_treats", "cat_training","cat_toy"];
let small_animal_types = ["rabbit_food","hamster_food"];




let id;
let items = [];
/*for(id=0;id<100;id++){
    let rand_price = prices[Math.floor(Math.random() * 17)];  
    let rand_brand_id = brand_ids[Math.floor(Math.random() * 27)];
    let rand_sale_date = sale_dates[Math.floor(Math.random() * 6)];
    let rand_current_quantities = current_quantities[Math.floor(Math.random() * 6)];
    let rand_animal_type = animal_types[Math.floor(Math.random() * 3)];
    let rand_item_type;
    if(rand_animal_type == "dog"){
        rand_item_type = dog_types[Math.floor(Math.random() * 5)];
    }
    else if(rand_animal_type == "cat"){
        rand_item_type = cat_types[Math.floor(Math.random() * 5)];
    }
    else{
        rand_item_type  = small_animal_types[Math.floor(Math.random() * 2)];
    }
    
    items.push(new item(id,rand_price,rand_brand_id,rand_animal_type,rand_item_type,rand_sale_date,rand_current_quantities));
}*/

//console.log(items);

function writeItem(items){
    let i;
    for(i=0;i<items.length;i++){
        firebase.database().ref('items/' + items[i].id).set({
            id: items[i].id,
            name: items[i].name,
            price: items[i].price,
            brand_id: items[i].brand_id,
            brand_name: items[i].brand_name,
            animal_type: items[i].animal_type,
            item_type: items[i].item_type,
            sale_date: items[i].sale_date,
            current_quantity: items[i].current_quantity,
            comments: items[i].comments,
            saled_quantity: items[i].saled_quantity,
            keyword: items[i].keyword
        }).catch((error) => {
            console.log(error.message);
        })
    }
  }
  
//writeItem(items);

function set_filter(n){
    let filter = JSON.parse(localStorage.getItem("filter"));
    let canPush = true;

    
    if(n=="dog"||n=="cat"||n=="small_animal"){
        reset_filter();
    }
    if(n=="dog"){
        localStorage.setItem("filter",JSON.stringify(["dog_food","dog_milk", "dog_treats", "dog_training","dog_toy"]));
        filter = JSON.parse(localStorage.getItem("filter"));

        for(i=0;i<filter.length;i++){
            document.getElementById(filter[i]+"_input").checked = true;
        }
    }
    else if(n=="cat"){
        localStorage.setItem("filter",JSON.stringify(["cat_food","cat_milk", "cat_treats", "cat_training","cat_toy"]));
        filter = JSON.parse(localStorage.getItem("filter"));
        let i;
        for(i=0;i<filter.length;i++){
            document.getElementById(filter[i]+"_input").checked = true;
        }
    }
    else if(n=="small_animal"){
        localStorage.setItem("filter",JSON.stringify(["rabbit_food","hamster_food"]));
        filter = JSON.parse(localStorage.getItem("filter"));
        let i;
        for(i=0;i<filter.length;i++){
            document.getElementById(filter[i]+"_input").checked = true;
        }
    }
    else if(n=="toy"){
        localStorage.setItem("filter",JSON.stringify(["dog_toy","cat_toy"]));
        filter = JSON.parse(localStorage.getItem("filter"));
        let i;
        for(i=0;i<filter.length;i++){
            document.getElementById(filter[i]+"_input").checked = true;
        }
    }
    else{
        for(i=0;i<filter.length;i++){
            if(n == filter[i] && document.getElementById(n+"_input").checked!=true){
                filter.splice(i,1);
                canPush = false;
            }
        }

        if(canPush){
            document.getElementById(n+"_input").checked = true;
            filter.push(n);
        }
        localStorage.setItem("filter",JSON.stringify(filter));
    }
    console.log(filter);
    show_item_list(1);
    active_items();
}

function change_comments_order(){
    let comments_order_dropdown = document.getElementsByClassName("comments_order_dropdown");   
    if(comments_order_dropdown[0].classList.contains("active")){
        comments_order_dropdown[0].classList.remove("active");
        comments_order_dropdown[1].classList.add("active");
    }else{
        comments_order_dropdown[1].classList.remove("active");
        comments_order_dropdown[0].classList.add("active");
    }

    let id = document.getElementById("item_id").innerHTML;
    get_comments(id);
}

function add_comment(){
    let comment_text = document.getElementById("comment_text").value;
    document.getElementById("comment_text").value = "";
    let today = new Date();
    let date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate(); 

    let comment = {
        'comment': comment_text,
        'date': date
    };
    
    let comments;
    let id = document.getElementById("item_id").innerHTML;
    let comment_db = firebase.database().ref('comments/'+ id);
    comment_db.on("value",function(snapshot){
        if (snapshot.child("comments").exists()) {
            comments = snapshot.val().comments;
        }
        else{
            comments = [];
        }
    });
    comments.push(comment);
    comment_db.set({
        'comments': comments
    })
    get_comments(id);
}

function get_comments(id){
    document.getElementById("comments").innerHTML="";
    let comment_db = firebase.database().ref('comments/'+ id);
    comment_db.on("value",function(snapshot){
        if (snapshot.child("comments").exists()) {
            snapshot.forEach(snap => {
                console.log(snap);
                console.log(snap.val());
                
                let comments = snap.val();

                let comments_order_dropdown = document.getElementsByClassName("comments_order_dropdown");
                if(comments_order_dropdown[0].classList.contains("active")){
                    comments.sort(function(a,b){
                        if(a.date < b.date) return 1;
                        if(a.date > b.date) return -1;
                    });
                }else{
                    comments.sort(function(a,b){
                        if(a.date < b.date) return -1;
                        if(a.date > b.date) return 1;
                    });
    
                }

                let i;
                for(i=0;i<comments.length;i++){  
                    document.getElementById("comments").innerHTML+=
                    `
                        <div style="min-height:150px;" class="rounded border bg-dark text-light"><p style="float: right; margin-right:5px;">Date: ${comments[i].date}</p><br><p class="display-6 ml-3" style="position:relative;">${comments[i].comment}</p></div>
                    `;
                    document.getElementById("comments").innerHTML+= "<hr>";
                }
               
            })
            console.log(document.getElementById("comments").innerHTML);
        }
        else{
            console.log("no comment");
        }
    });

}



function get_item(id){
    active_item();

    let item_info = document.getElementsByClassName("item_info");
    let item_photo = document.getElementById("item_photo");
    let item_db = firebase.database().ref('items/'+ id);

    item_db.on("value",function(snapshot){
        const issue = snapshot.val();
        item_photo.innerHTML =  issue.id;
        item_info[0].innerHTML =  issue.id;
        item_info[1].innerHTML =  issue.name;
        item_info[2].innerHTML = issue.price;
        item_info[3].innerHTML = issue.brand_name;
        item_info[4].innerHTML = issue.sale_date;
        item_info[5].innerHTML = issue.current_quantity;
        item_info[6].innerHTML = issue.saled_quantity;
        item_info[7].innerHTML = issue.item_type;
    });
    get_comments(id);
    document.getElementById("item_cart_quantity").value = 1;
    let addCartButton = document.getElementById("addCartButton");
    addCartButton.addEventListener("click",function(){
        let item_cart_quantity = document.getElementById("item_cart_quantity");
        add_cart(id,item_cart_quantity.value);
    })
    
    let pre_item_button = document.getElementById("pre_item_button");
    let next_item_button = document.getElementById("next_item_button");

    if(id-1>-1){
        pre_item_button.addEventListener("click",function (){ 
            get_item(id-1);     
        });
    }

    if(id+1<100){
        next_item_button.addEventListener("click",function (){
            get_item(id+1);
        });
    }

}



function getTotalPrice(){
    let cart_items_price = document.getElementsByClassName("total_price");
    let i;
    let sum=0;
    for(i=0;i<cart_items_price.length;i++){
        sum += parseInt(cart_items_price[i].innerText);
    }
    return sum;

}

function getAccountWallet(){
    let uid = localStorage.getItem("uid");
    let user_db = firebase.database().ref('users/'+ uid);
    let account_wallet; 
    user_db.on("value",function(snapshot){
        const user = snapshot.val();
        account_wallet = user.account_wallet;
    });
    return account_wallet;
  }


function setPriceAndWalletHtml(){
    document.getElementById("total_price").innerHTML = getTotalPrice();
    if(!firebase.database().ref('/users/'+localStorage.getItem("uid"))|| !localStorage.getItem("uid")){
        document.getElementById("account_wallet").innerHTML = "";
        document.getElementById("remain_wallet").innerHTML = "";
    }else{
        document.getElementById("account_wallet").innerHTML = getAccountWallet();
        document.getElementById("remain_wallet").innerHTML = getAccountWallet()-getTotalPrice();
        if(getAccountWallet()-getTotalPrice()<0){
            document.getElementById("remain_wallet").style.color = "red";
        }else{
            document.getElementById("remain_wallet").style.color = "black";
        }
    }
}

function changeTotalPrice(id,price){
    let total_price = `id_${id}_total_price`;
    let quantity = `quantity_${id}`;
    let quantity_value = document.getElementById(quantity).value;
    document.getElementById(total_price).innerHTML = price * quantity_value;

    setPriceAndWalletHtml();
}

function removeAllCartItem(){
    let cart_table_body = document.getElementById("cart_table_body");
    while(cart_table_body.firstChild){
        cart_table_body.removeChild(cart_table_body.firstChild);
    }
    let shopping_cart_number = document.getElementById("shopping_cart_number");
    shopping_cart_number.innerHTML = 0;
    if(isEmptyCart()){
        document.getElementById("not_empty_cart").style.display = "none";
        document.getElementById("empty_cart").style.display = "block";
    }else{
        document.getElementById("not_empty_cart").style.display = "block";
        document.getElementById("empty_cart").style.display = "none";
    } 
}

function removeCartItem(id){
    let cart_table_body = document.getElementById("cart_table_body");
    let cart_items = document.getElementsByClassName("cart_items");
    let cart_item = document.getElementById(`cart_item_${id}`);
    let shopping_cart_number = document.getElementById("shopping_cart_number");
    cart_table_body.removeChild(cart_item);
    shopping_cart_number.innerHTML = parseInt(shopping_cart_number.innerHTML) - 1;
    if(shopping_cart_number.innerHTML == 0){
        if(isEmptyCart()){
            document.getElementById("not_empty_cart").style.display = "none";
            document.getElementById("empty_cart").style.display = "block";
          }else{
            document.getElementById("not_empty_cart").style.display = "block";
            document.getElementById("empty_cart").style.display = "none";
          } 
    }else{
        let j;
        for(j=0;j<cart_items.length;j++){
            cart_items[j].childNodes[1].innerHTML = j+1;
        }
        setPriceAndWalletHtml();
    }
}


function add_cart(id,n){
    let item_db = firebase.database().ref('items/'+ id);
    let item;

    item_db.on("value",function(snapshot){
        item = snapshot.val();
    });
    let cart_item_name = document.getElementsByClassName("cart_item_name");
    let j;
    let isCartItem = false;
    for(j=0;j<cart_item_name.length;j++){
        if(cart_item_name[j].innerHTML == item.name){
            isCartItem = true;
            break;
        }
    }
    if(item.current_quantity>=n && isCartItem==false){
        let shopping_cart_number = document.getElementById("shopping_cart_number");
        let num = parseInt(shopping_cart_number.innerHTML) + 1
        shopping_cart_number.innerHTML = num;

        if(shopping_cart_number.innerHTML == "1"){
            if(isEmptyCart()){
                document.getElementById("not_empty_cart").style.display = "none";
                document.getElementById("empty_cart").style.display = "block";
              }else{
                document.getElementById("not_empty_cart").style.display = "block";
                document.getElementById("empty_cart").style.display = "none";
              }
        }
        let total_price = item.price * n;
        let cart_table_body = document.getElementById("cart_table_body");
        cart_table_body.innerHTML += `
            <tr style="text-align:center;" class="cart_items" id="cart_item_${item.id}">
                <th class="cart_item_number" scope="row">${shopping_cart_number.innerText}</th>
                <td class="cart_item_id">${item.id}</td>
                <td class="cart_item_name">${item.name}</td>
                <td class="cart_item_price">${item.price}</td>
                <td><input type="number" style="text-align: center;" onchange="changeTotalPrice(${item.id},${item.price})" id="quantity_${item.id}" name="quantity_${item.id}" min="1" max="${item.current_quantity}" value="${n}"></td>
                <td id="id_${item.id}_total_price" class="total_price">${total_price}</td>
                <td><button onclick="removeCartItem(${item.id})" class="btn btn-primary style="width: 100%; text-align: center;">Delete</button></td>
            </tr>
        `
    }
    else if(isCartItem){
        alert("Item " + id + " is already in Cart.");
    }
    else{
        alert("Item " + id + " no quantity now.\nWe are filling the quantity as soon as possible.");
    }
    setPriceAndWalletHtml();
}

function getRandomKey(){
    let randKey           = '';
    let characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()~|}{:">?<';
    let charactersLength = characters.length;
    for ( let i = 0; i < 32; i++ ) {
        randKey += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return randKey;
}

function addAccountWalletAmount(){
    let walletKeys_db = firebase.database().ref('walletKey');
    let walletKeys;
    walletKeys_db.on("value",function(snapshot){
        walletKeys = snapshot.val();
    });
    let i;
    let user_input_accountKey = document.getElementById("user_input_accountKey");
    let isValid = false;
    if(user_input_accountKey.value!=""){

        for(i=0;i<5;i++){
            if(walletKeys[i].key == user_input_accountKey.value){
                isValid = true;
                break;
            }
        }   
        
        if(isValid){
            let uid = localStorage.getItem("uid");
            let user_db = firebase.database().ref('users/'+ uid);
            let account_wallet; 
            let value;
            user_db.on("value",function(snapshot){
                const user = snapshot.val();
                account_wallet = user.account_wallet + walletKeys[i].value; 
                value = walletKeys[i].value;          
            });
            user_db.update({'account_wallet': account_wallet});
            firebase.database().ref('walletKey/'+i).update({'key': getRandomKey()});
            user_input_accountKey.value ="";
            let account_wallet_input = document.getElementById("account_wallet_input");
            account_wallet_input.value = account_wallet;
            alert("Your key is correct.\nYou added $" + value + "in your account wallet.");
        }else{
            alert("Your Key is not correct.\nPlease try again.");
        }
    }else{
        alert("Please input Key.");
    } 
    
}

function decreaseItemQuantity(id,quantity){
    let item_db = firebase.database().ref('items/'+id);
    let remain_quantity;
    item_db.on("value",function(snapshot){
        const issue = snapshot.val();
        remain_quantity = issue.current_quantity - quantity;
    });
    console.log(remain_quantity);
    item_db.update({'current_quantity':remain_quantity});
}


function getPaymentRecords(){
    let uid = localStorage.getItem("uid");
    let paymentRecords_db = firebase.database().ref('paymentRecords/'+ uid);
    let paymentRecords;
    paymentRecords_db.on("value",function(snapshot){
        const issue = snapshot.val();
        paymentRecords =  issue;
        if(paymentRecords){
            console.log("ok");
            document.getElementById("empty_payment_record").style.display = "none";
            document.getElementById("not_empty_payment_record").style.display = "block";
    
            let not_empty_payment_record = document.getElementById("not_empty_payment_record");
            not_empty_payment_record.innerHTML = "";
            for(let i=0;i<paymentRecords.length;i++){
                not_empty_payment_record.innerHTML += 
                `
                    <table class="table table-striped mb-5 payment_record_table rounded table-dark">
                        <thead>
                            <tr style="text-align:center;">
                                <th scope="col">#</th>
                                <th scope="col">Id</th>
                                <th scope="col">Item</th>
                                <th scope="col">Price</th>
                                <th scope="col">Qauntity</th>
                                <th scope="col">Total Price</th>
                            </tr>
                        </thead>
                        <tbody class="payment_record_table_body">
                        </tbody>
                    </table>
    
                `;
                console.log(not_empty_payment_record.innerHTML);
                if(i<paymentRecords.length-1){
                    not_empty_payment_record.innerHTML += "<hr>";
                }
                let payment_record_table = document.getElementsByClassName("payment_record_table");
                for(let j=0;j<paymentRecords[i][0].record_items.length;j++){
                    payment_record_table[i].innerHTML +=
                    `
                        <tr style="text-align:center;">
                            <th scope="row">${paymentRecords[i][0].record_items[j].number}</th>
                            <td>${paymentRecords[i][0].record_items[j].id}</td>
                            <td>${paymentRecords[i][0].record_items[j].item}</td>
                            <td>${paymentRecords[i][0].record_items[j].price}</td>
                            <td>${paymentRecords[i][0].record_items[j].quantity}</td>
                            <td>${paymentRecords[i][0].record_items[j].total_price}</td>
                        </tr>
                    `;
                }
                payment_record_table[i].innerHTML += 
                `
                    <tr class="text-primary" style="text-align:center;">
                        <td colspan="4">Shipping Address: ${paymentRecords[i][0].shipping_address}</td>
                        <td>Total Price: ${paymentRecords[i][0].record_total_price}</td>
                        <td>Date: ${paymentRecords[i][0].Date}</td>
                    </tr>
                `;
            }
        }else{
            document.getElementById("not_empty_payment_record").style.display = "none";
            document.getElementById("empty_payment_record").style.display = "block";
        }
    }); 

}

function addPaymentRecord(){
    let uid = localStorage.getItem("uid");
    let paymentRecords_db = firebase.database().ref('paymentRecords/'+ uid);

    let paymentRecords = [];

    paymentRecords_db.on("value",function(snapshot){
        const issue = snapshot.val();
        paymentRecords = issue;
    });

    console.log(paymentRecords);

    let paymentRecord = [];
    let paymentRecord_item;
    let cart_items = document.getElementsByClassName("cart_items");
    let cart_item_number = document.getElementsByClassName("cart_item_number");
    let cart_item_id = document.getElementsByClassName("cart_item_id");
    let cart_item_name = document.getElementsByClassName("cart_item_name");
    let cart_item_price = document.getElementsByClassName("cart_item_price");
    let total_price = document.getElementsByClassName("total_price");


    for(let i=0;i<cart_items.length;i++){
        paymentRecord_item = {
            'number': cart_item_number[i].innerHTML,
            'id': cart_item_id[i].innerHTML,
            'item': cart_item_name[i].innerHTML,
            'price': cart_item_price[i].innerHTML,
            'quantity': document.getElementById(`quantity_${cart_item_id[i].innerHTML}`).value,
            'total_price': total_price[i].innerHTML
        }
        console.log(paymentRecord);
        paymentRecord.push(paymentRecord_item);
        decreaseItemQuantity(cart_item_id[i].innerHTML,document.getElementById(`quantity_${cart_item_id[i].innerHTML}`).value);
    }

    console.log(paymentRecord);

    let today = new Date();
    let date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
    let x = {
        'record_items':paymentRecord,
        'record_total_price': getTotalPrice(),
        'Date': date,
        'shipping_address': document.getElementById("shipping_address").innerHTML
    }

    paymentRecords.push([x]);

    console.log(paymentRecords);


    paymentRecords_db.set(
        paymentRecords
    );
}

function account_wallet_checkout(){
    if(getAccountWallet()-getTotalPrice()>0){
        addPaymentRecord();
        removeAllCartItem();
        let uid = localStorage.getItem("uid");
        let user_db = firebase.database().ref('users/'+ uid);
        user_db.update({'account_wallet':document.getElementById("remain_wallet").innerHTML});
        alert("Sucess!\n You could check your payment record in 'Payment Record'.\n Your current account wallet amount is " + document.getElementById("remain_wallet").innerHTML);
    }else{
        alert("You do not have enough money in your account wallet.\nPlease add more money in your account wallet.\nOr choose other payment method.");
    }
}



function checkout(){
    if(!firebase.database().ref('/users/'+localStorage.getItem("uid"))|| !localStorage.getItem("uid")){
        alert("Please Login.");
    }else{
        if(document.getElementById("account_wallet_Radio").checked){
            account_wallet_checkout();
        }
    }
}
    

function filter_price(){
    localStorage.setItem("price_filter",JSON.stringify([ $( "#slider-range" ).slider( "values", 0 ),$( "#slider-range" ).slider( "values", 1 )]));
    show_item_list(1);
    active_items();
}

function reset_search(){
    document.getElementById("search_value").value = "";
}

function reset_filter(){
    reset_search();
    localStorage.setItem("filter",JSON.stringify([]));
    localStorage.setItem("price_filter",JSON.stringify([0,500]));
    $("#slider-range").slider('values',0,0);
    $("#slider-range").slider('values',1,500);
    $("#min_price")[0].innerHTML=$( "#slider-range" ).slider( "values", 0 );
    $("#max_price")[0].innerHTML=$( "#slider-range" ).slider( "values", 1 );
    let all_types = [];
    let i;
    for(i=0;i<brand_ids.length;i++){
        all_types.push("brand_"+brand_ids[i]);
    }
    for(i=0;i<dog_types.length;i++){
        all_types.push(dog_types[i]);
    }
    for(i=0;i<cat_types.length;i++){
        all_types.push(cat_types[i]);
    }
    for(i=0;i<small_animal_types.length;i++){
        all_types.push(small_animal_types[i]);
    }
    for(i=0;i<all_types.length;i++){
        document.getElementById(all_types[i]+"_input").checked = false;
    }
}

function reset_filter_and_show_items(){
    let filter = JSON.parse(localStorage.getItem("filter"));
    reset_filter();
    console.log(filter);
    show_item_list(1);
    active_items();
}

function set_sort_by(n){
    let sort_by_dd_item = document.getElementsByClassName("sort_by_dd_item");
    let i;
    for(i=0;i<sort_by_dd_item.length;i++){
        sort_by_dd_item[i].classList.remove("active");
    }
    localStorage.setItem("sort_by",JSON.stringify(n));
    sort_by_dd_item[n].classList.add("active");

    show_item_list(1);
}

function set_items_perpage(n,m){
    let items_perpage_dd_item = document.getElementsByClassName("items_perpage_dd_item");
    let i;
    for(i=0;i<items_perpage_dd_item.length;i++){
        items_perpage_dd_item[i].classList.remove("active");
    }
    items_perpage_dd_item[m].classList.add("active");
    localStorage.setItem("items_perpage",JSON.stringify(n));

    show_item_list(1);
}

function search(){    
    show_item_list(1);
    if(document.getElementById("items").classList.contains("fade")||!document.getElementById("items").classList.contains("active")){
        active_items();
    }
}

localStorage.setItem("filter",JSON.stringify([]));
localStorage.setItem("price_filter",JSON.stringify([0,500]));
localStorage.setItem("sort_by",JSON.stringify(0));
localStorage.setItem("items_perpage",JSON.stringify(25));

function show_item_list(page){
    let search_value = document.getElementById("search_value").value.toLowerCase();
    console.log(search_value);
    let filter = JSON.parse(localStorage.getItem("filter"));
    let price_filter = JSON.parse(localStorage.getItem("price_filter"));
    let sort_by = JSON.parse(localStorage.getItem("sort_by"));
    let items_perpage = JSON.parse(localStorage.getItem("items_perpage"));

    let reset_filter_button = document.getElementById("reset_filter_button");
    
    if(filter.length>0||price_filter[0]>0||price_filter[1]<500||search_value.length>0){
        reset_filter_button.style.display = "block";
    }else{
        reset_filter_button.style.display = "none";
    }

    document.getElementById("item_list").innerHTML = "";
    let items_db = firebase.database().ref('items');

    let number_of_items_found = 0;
    document.getElementById("number_of_items_found").innerHTML = number_of_items_found;

    let items = [];

    items_db.on("value",function(snapshot){
        snapshot.forEach(snap => {
            const issue = snap.val();
            items.push(issue);
        })
        switch(sort_by){
            case 0: break;
            case 1: 
                items.sort(function(a,b){
                    if(a.current_quantity < b.current_quantity) return 1;
                    if(a.current_quantity > b.current_quantity) return -1;
                    return 0;
                });break;
            case 2:
                items.sort(function(a,b){
                    if(a.sale_date < b.sale_date) return 1;
                    if(a.sale_date > b.sale_date) return -1;
                    return 0;
                });break;
            case 3:
                items.sort(function(a,b){
                    if(a.saled_quantity < b.saled_quantity) return 1;
                    if(a.saled_quantity > b.saled_quantity) return -1;
                    return 0;
                });break;
            case 4:
                items.sort(function(a,b){
                    if(a.price < b.price) return -1;
                    if(a.price > b.price) return 1;
                    return 0;
                });break;
            case 5:
                items.sort(function(a,b){
                    if(a.price < b.price) return 1;
                    if(a.price > b.price) return -1;
                    return 0;
                });break;
        }
        


        let k = 0;
        let x = items.length;
        let items_filtered = [];
        for(k;k< x;k++){
            let i,j;
            let haveKeyword;
            let withinprice;
            let inSearch = false;
            if(filter.length!=0){
                haveKeyword = false;
                for(i=0;i<filter.length;i++){
                    for(j=0;j<items[k].keyword.length;j++){
    
                        if(items[k].keyword[j] == filter[i]){
                            haveKeyword = true;
                            break;
                        }
                    }
                }
            }else{
                haveKeyword = true;
            }
            if(price_filter[0]<=items[k].price&&items[k].price<=price_filter[1]){
                withinprice = true;
            }else
            {
                withinprice = false;
            }

            if(search_value.length>0){
                let j;
                for(j=0;j<items[k].keyword.length;j++){   
                    if(items[k].keyword[j] == search_value){
                        inSearch = true;
                        break;
                    }
                }
            }
            else{
                inSearch = true;
            }
            if(haveKeyword==true&&withinprice==true&&inSearch==true){
                number_of_items_found +=1;
                document.getElementById("number_of_items_found").innerHTML = number_of_items_found;
                items_filtered.push(items[k]);
            }
        }
        if(items_perpage>items_filtered.length-items_perpage*(page-1)){
            x = items_filtered.length;
        }
        else{
            x = items_perpage*page;
        }

        if(page==0){
            k = 0;
        }
        else{
            k = (page-1)*items_perpage;
        }
        for(k;k< x;k++){
            document.getElementById("item_list").innerHTML +=
            `
                <div class="card mr-auto item_card" onMouseOver="this.style.transform= 'scale(1.05)'" onMouseOut="this.style.transform= 'scale(1)'"  style="cursor: pointer; margin: 20px; width:200px;height:340px; transition: all 0.3s; border: 1px solid black;">
                    <div onclick="get_item(${items_filtered[k].id})">
                        <i class="card-img-top fa fa-paw fa-5x bg-dark text-light " aria-hidden="true" style="padding: 0 25%;"></i>
                        <div class="card-body">
                            <h4 class="card-title">${items_filtered[k].name}</h4>
                            <p class="card-text" style="height:120px"><strong>Price:</strong> ${items_filtered[k].price}<br><strong>Brand:</strong> ${items_filtered[k].brand_name}<br><strong>Year:</strong> ${items_filtered[k].sale_date}<br><strong>Type:</strong> ${items_filtered[k].item_type}<br><strong>Quantity:</strong> ${items_filtered[k].current_quantity}</p>
                        </div>
                    </div>           
                    <button onclick="add_cart(${items_filtered[k].id},1)" class="btn btn-dark" style="margin: 0 20px;">Add to Cart</button> 
                </div>
            `;
        }

        number_of_pages = Math.ceil(items_filtered.length/items_perpage);
        document.getElementById("pagination").innerHTML = "";

        if(number_of_pages==1||number_of_pages==0){
            document.getElementById("pagination").innerHTML += 
            `<nav>
                    <ul class="pagination pagination-lg justify-content-center">
                        <li class="page-item disabled"><a class="page-link"  tabindex="-1" >1</a></li>
                    </ul>
                </nav>
            `
        }
        else{
            let pagination_innerHTML ="";
            pagination_innerHTML += `<nav>
                    <ul class="pagination pagination-lg justify-content-center">
                        <li class="page-item" id="previous"><a class="page-link" onclick="show_item_list(${page-1});return false;"><span aria-hidden="true">&laquo;</span></a></li>
            `;
            
            let z;
            for(z=1;z<=number_of_pages;z++){
                pagination_innerHTML += 
                `<li class="page-item" id="page_${z}"><a class="page-link" onclick="show_item_list(${z});return false;">${z}</a></li>`;   
            }

            pagination_innerHTML +=
            `
                        <li class="page-item" id="next"><a class="page-link" onclick="show_item_list(${page+1});return false;"><span aria-hidden="true">&raquo;</span></a></li>
                    </ul>
                </nav>
            `;
            document.getElementById("pagination").innerHTML = pagination_innerHTML;
            if(page-1<=0){
                document.getElementById("previous").classList.add("disabled");
                document.getElementById("previous").firstChild.setAttribute("tabindex","-1");
            }
            if(page+1>number_of_pages){
                document.getElementById("next").classList.add("disabled");
                document.getElementById("next").firstChild.setAttribute("tabindex","-1");
            }
            document.getElementById("page_"+page).classList.add("active");
        }
    })   
}

show_item_list(1);

$("#search_value").on('keydown', function (e) {
    if (e.key == 'Enter' || e.keyCode == 13) {
        return false;
    }
});


function set_item_card_width(mq){
    let item_card = document.getElementsByClassName("item_card");
    let i;
    if (mq.matches) {
        for(i=0;i<item_card.length;i++){
            item_card[i].style.width = "100%";
            item_card[i].style.marginLeft = 0;
        }
    }
    else{
        for(i=0;i<item_card.length;i++){
            item_card[i].style.width = "200px";
            item_card[i].style.margin = "20px";
        }
    }
}
const mq = window.matchMedia('(max-width: 800px)');
set_item_card_width(mq);
mq.addListener(set_item_card_width);

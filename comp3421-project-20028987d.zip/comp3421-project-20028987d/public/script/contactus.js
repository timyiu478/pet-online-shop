function sendForm(){
    emailjs.sendForm('service_vfnpqsg', 'template_xrcg19b', '#contact-form')
        .then(function() {
            alert('Email Sent Successfully.\nThanks for contact us.');
            document.getElementById("name").value = "";
            document.getElementById("title").value = "";
            document.getElementById("message").value = "";
            document.getElementById("email").value = "";
            return true;
        }, function(error) {
            alert('FAILED...', error);
        });
}


document.getElementById('contact-form').addEventListener('submit', function(event) {
    event.preventDefault();
    sendForm();
});



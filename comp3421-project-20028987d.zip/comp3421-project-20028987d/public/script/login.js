function login_auth(event){

  let email = document.getElementById("email");
  let password = document.getElementById("password");

  firebase.auth().signInWithEmailAndPassword(email.value, password.value).then(() =>{
    let isEmailVerified = firebase.auth().currentUser.emailVerified;
    if(isEmailVerified == true){
      localStorage.setItem("uid",firebase.auth().currentUser.uid);
      alert("login Successfully");
      window.location.href="index.html";
    }
    else{
      alert("Please verify your email.");
    }

  })
  .catch((error) => {
    const errorCode = error.code;
    const errorMessage = error.message;
    alert("Error: " + errorMessage + "\n" + "Error Code: " +errorCode);
  });

}



function go_to_homepage(){
  window.location.href="index.html";
}

function logout(){
  localStorage.removeItem("uid");
  isLogin();
}

function isLogin(){
  let login_button = document.getElementById("login_button");
  if(firebase.database().ref('/users/'+localStorage.getItem("uid"))!=null&&localStorage.getItem("uid")!=null){
    login_button.setAttribute("data-toggle","modal");
    login_button.setAttribute("data-target","#already_login_dialog");
    login_button.setAttribute("onclick","");
  }
  else{
    login_button.removeAttribute("data-toggle","modal");
    login_button.removeAttribute("data-target","#already_login_dialog");
    login_button.setAttribute("onclick","login_auth(event)");
  }
}

window.onload = function(){
  isLogin();
}



function enter(){
  if(window.event.keyCode==13){
    login_auth(event);
  }
}

